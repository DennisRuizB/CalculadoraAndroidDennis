package edu.dsa.dennis.calculadoradennis;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private TextView LblResultado;
    private TableLayout TablaNums;
    private TableRow TableRow1;
    private String Resultado = "";
    int numero1 = 0;
    int numero2 = 0;
    String operacion = "";
    String mode = "Rad";  // por defecto radiantes

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        LblResultado = findViewById(R.id.LblResultado);
        TablaNums = findViewById(R.id.TablaBotones);
        TableRow1 = findViewById(R.id.TableRow1);


        // Recorrer todas las filas del TableLayout
        for (int i = 0; i < TablaNums.getChildCount(); i++) {
            View row = TablaNums.getChildAt(i);

            if (row instanceof TableRow) {
                TableRow tableRow = (TableRow) row;

                // Recorrer todos los botones en la fila
                for (int j = 0; j < tableRow.getChildCount(); j++) {
                    View view = tableRow.getChildAt(j);

                    if (view instanceof Button) {
                        Button button = (Button) view;

                        // Configurar el OnClickListener para cada botón
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                // Manejar la acción del botón
                                Button clickedButton = (Button) v;
                                String buttonText = clickedButton.getText().toString();

                                if (!Objects.equals(buttonText, "+") && !Objects.equals(buttonText, "=") && !Objects.equals(buttonText, "-")
                                        && !Objects.equals(buttonText, "x") && !Objects.equals(buttonText, "/")
                                        && !Objects.equals(buttonText, "Sin") && !Objects.equals(buttonText, "Cos") && !Objects.equals(buttonText, "Tan")) {
                                    Resultado = Resultado + buttonText;
                                }

                                if (Objects.equals(buttonText, "AC")) {
                                    Resultado = "";
                                    numero1 = 0;
                                    numero2 = 0;
                                    operacion = "";
                                }
                                if (Objects.equals(buttonText, "+")) {
                                    numero1 = Integer.parseInt(Resultado);
                                    Resultado = "";
                                    operacion = "suma";
                                }
                                if (Objects.equals(buttonText, "x")) {
                                    numero1 = Integer.parseInt(Resultado);
                                    Resultado = "";
                                    operacion = "multiplicacion";
                                }
                                if (Objects.equals(buttonText, "/")) {
                                    numero1 = Integer.parseInt(Resultado);
                                    Resultado = "";
                                    operacion = "division";
                                }
                                if (Objects.equals(buttonText, "-")) {
                                    numero1 = Integer.parseInt(Resultado);
                                    Resultado = "";
                                    operacion = "resta";
                                }

                                if (Objects.equals(buttonText, "Sin")) {
                                    numero1 = Integer.parseInt(Resultado);
                                    operacion = "Sin";
                                }
                                if (Objects.equals(buttonText, "Cos")) {
                                    numero1 = Integer.parseInt(Resultado);
                                    operacion = "Cos";
                                }
                                if (Objects.equals(buttonText, "Tan")) {
                                    numero1 = Integer.parseInt(Resultado);
                                    operacion = "Tan";
                                }

                                if (Objects.equals(buttonText, "Deg")) {
                                    mode = "Deg";
                                    Resultado = "";
                                }
                                if (Objects.equals(buttonText, "Rad")) {
                                    mode = "Rad";
                                    Resultado = "";
                                }

                                // Cuando le damos a "="
                                if (Objects.equals(buttonText, "=")) {
                                    if (!Objects.equals(Resultado, "")) {
                                        numero2 = Integer.parseInt(Resultado);
                                    }
                                    if (Objects.equals(operacion, "suma")) {
                                        Resultado = Integer.toString(suma(numero1, numero2));
                                    }
                                    if (Objects.equals(operacion, "resta")) {
                                        Resultado = Integer.toString(resta(numero1, numero2));
                                    }
                                    if (Objects.equals(operacion, "multiplicacion")) {
                                        Resultado = Integer.toString(multiplicacion(numero1, numero2));
                                    }
                                    if (Objects.equals(operacion, "division")) {
                                        Resultado = Integer.toString(division(numero1, numero2));
                                    }
                                    // Cálculo operaciones trigonométricas
                                    if (Objects.equals(operacion, "Sin")) {
                                        Resultado = operacionTrigonometrica("Sin", (double) numero1, mode);
                                    }
                                    if (Objects.equals(operacion, "Cos")) {
                                        Resultado = operacionTrigonometrica("Cos", (double) numero1, mode);
                                    }
                                    if (Objects.equals(operacion, "Tan")) {
                                        Resultado = operacionTrigonometrica("Tan", (double) numero1, mode);
                                    }

                                    // Reiniciar números después de la operación
                                    numero1 = 0;
                                    numero2 = 0;
                                }

                                LblResultado.setText(Resultado);
                            }
                        });
                    }
                }
            }
        }
    }

    // Funciones operaciones
    public int suma(int a, int b) {
        return a + b;
    }

    public int resta(int a, int b) {
        return a - b;
    }

    public int multiplicacion(int a, int b) {
        return a * b;
    }

    public int division(int a, int b) {
        return a / b;
    }

    // Función operaciones trigonométricas
    public String operacionTrigonometrica(String operacion, double valor, String mode) {
        double resultado;
        // Convertir a radianes si el modo es "Deg"
        if (Objects.equals(mode, "Deg")) {
            valor = Math.toRadians(valor);
        }

        switch (operacion) {
            case "Sin":
                resultado = Math.sin(valor);
                break;
            case "Cos":
                resultado = Math.cos(valor);
                break;
            case "Tan":
                resultado = Math.tan(valor);
                break;
            default:
                resultado = 0;
        }
        // redondeamos el resultado para evitar algunos casos que devuelve numeros muy pequeños en vez de 0
        resultado = Math.round(resultado * 1000000000.0) / 1000000000.0;
        return String.valueOf(resultado);
    }
}
